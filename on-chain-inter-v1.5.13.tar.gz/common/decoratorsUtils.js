"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.timeout = timeout;
/**
 * 装饰器，限定函数执行超时时间，超过设置得时间则自动跳过执行下一步
 * @timeout(1000) // 限时1000ms
 * @param limit
 * @returns
 */
function timeout(limit) {
    return function (target, propertyKey, descriptor) {
        const originalMethod = descriptor.value;
        descriptor.value = async function (...args) {
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error('Execution timeout')), limit);
            });
            try {
                return await Promise.race([
                    originalMethod.apply(this, args),
                    timeoutPromise
                ]);
            }
            catch (error) {
                if (error.message === 'Execution timeout') {
                    console.log(`Method ${propertyKey} exceeded ${limit}ms, skipped`);
                    return `Method ${propertyKey} exceeded ${limit}ms, skipped`; // 跳过执行
                }
                throw error;
            }
        };
        return descriptor;
    };
}
//# sourceMappingURL=decoratorsUtils.js.map