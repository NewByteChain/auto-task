"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userlist = exports.groupList = exports.groupUpdate = exports.groupCreate = exports.browserActive = exports.browserStop = exports.browserStart = exports.apiStatus = exports.getDexData = void 0;
const result_code_1 = __importDefault(require("../common/result.code"));
const monitorSolDebotService = __importStar(require("../services/mutual.service"));
const flowAdsPowerService = __importStar(require("../services/flow.adspower.task"));
// 这里可以添加类型声明和其他逻辑
/**
 * 获取Debot交易所指定token得交易数据
 * @param {*} req
 * @param {*} res
 * @returns
 */
const getDexData = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return monitorSolDebotService.getDexData(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[getGmgnKline]查询出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.getDexData = getDexData;
/**
 * AdsPower apiStatus: API接口状态
 * @param req
 * @param res
 * @returns
 */
const apiStatus = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.apiStatus().then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[apiStatus] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.apiStatus = apiStatus;
/**
 * 启动浏览器
 * @param req
 * @param res
 * @returns
 */
const browserStart = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.browserStart(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[browserStart] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.browserStart = browserStart;
const browserStop = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.browserStop(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[browserStop] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.browserStop = browserStop;
/**
 *
 * @param req
 * @param res
 * @returns
 */
const browserActive = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.browserActive(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[browserStop] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.browserActive = browserActive;
/**
 * 创建分组
 * @param req
 * @param res
 * @returns
 */
const groupCreate = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.groupCreate(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[groupCreate] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.groupCreate = groupCreate;
/**
 * 修改分组
 * @param req
 * @param res
 * @returns
 */
const groupUpdate = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.groupUpdate(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[groupUpdate] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.groupUpdate = groupUpdate;
/**
 * 查询分组
 * @param req
 * @param res
 * @returns
 */
const groupList = async (req, res) => {
    // params
    var body = req.query;
    // Fractal分析数据查询
    return flowAdsPowerService.groupList(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[groupList] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.groupList = groupList;
/**
 * 查询环境
 * @param req
 * @param res
 * @returns
 */
const userlist = async (req, res) => {
    // params
    var body = req.query;
    return flowAdsPowerService.userlist(body).then(data => {
        // 返回参数已经封装好了，这里直接返回就可以了
        res.status(200).json(result_code_1.default.returnSuccess(req.headers, data));
    }).catch(ex => {
        console.error('[groupList] 出现异常>>', ex);
        res.status(200).json(result_code_1.default.returnError(req.headers, ex, null));
    });
};
exports.userlist = userlist;
//# sourceMappingURL=mutualController.js.map