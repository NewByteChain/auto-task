"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.globalReferralCode = exports.globalState = void 0;
/**
 * 钱包导入标志KEY缓存
 */
exports.globalState = {
    // 钱包导入状态，存储用户钱包缓存目录
    WALLET_IMPORT_STATE_KEY: "",
    // 网站连接钱包状态
    WEBSITE_WALLET_CONNECT: false
};
/**
 * KLOKAPP.AI 邀请码
 */
exports.globalReferralCode = {
    KLOKAPP_REFERRAL_CODE: [],
    CORESKY_REFERRAL_CODE: []
};
//# sourceMappingURL=globalState.js.map