"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=menu.interface.js.map