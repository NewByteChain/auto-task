"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const mutualController = __importStar(require("../controller/mutualController"));
const router = (0, express_1.Router)();
// 测试方法
router.get('/test', mutualController.getDexData);
// AdsPower http://localhost:9300/api/mutual/api-status
router.get('/api-status', mutualController.apiStatus);
// AdsPower http://localhost:9300/api/mutual/browser-start?user_id=user_hskx5c
router.get('/browser-start', mutualController.browserStart);
// AdsPower http://localhost:9300/api/mutual/browser-stop?user_id=user_hskx5c
router.get('/browser-stop', mutualController.browserStop);
// AdsPower http://localhost:9300/api/mutual/browser-active?user_id=user_hskx5c
router.get('/browser-active', mutualController.browserActive);
// AdsPower 查询分组列表: http://localhost:9300/api/mutual/group-list
router.get('/group-list', mutualController.groupList);
// AdsPower 查询分组列表: http://localhost:9300/api/mutual/group-create?group_name=测试分组&remark=测试分组描述
router.get('/group-create', mutualController.groupCreate);
// AdsPower 查询分组列表: http://localhost:9300/api/mutual/group-update?group_id=5661422&group_name=测试分组&remark=测试分组描述
router.get('/group-update', mutualController.groupUpdate);
// AdsPower 查询分组列表: http://localhost:9300/api/mutual/user-list
router.get('/user-list', mutualController.userlist);
exports.default = router;
//# sourceMappingURL=mutualRoutes.js.map