"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiStatus = apiStatus;
exports.browserStart = browserStart;
exports.browserStop = browserStop;
exports.browserActive = browserActive;
exports.groupCreate = groupCreate;
exports.groupUpdate = groupUpdate;
exports.groupList = groupList;
exports.applicationList = applicationList;
exports.userCreate = userCreate;
exports.userUpdate = userUpdate;
exports.userlist = userlist;
exports.userDelete = userDelete;
exports.userRegroup = userRegroup;
exports.userDeleteCache = userDeleteCache;
const api_common_1 = require("./api.common");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
// adsPower API Host 和 Port
const ADSPOWER_API_HOST = process.env.ADSPOWER_API_HOST || 'local.adspower.net'; // AdsPower API Host
const ADSPOWER_API_PORT = process.env.ADSPOWER_API_PORT || '50325'; // AdsPower API Port
// ADSPOWER_API_HOTS
const ADSPOWER_API_URL = `http://${ADSPOWER_API_HOST}:${ADSPOWER_API_PORT}`;
const ADSPOWER_API_KEY = process.env.ADSPOWER_API_KEY || '';
/**
 * API接口状态
 * @returns
 */
async function apiStatus() {
    try {
        let url = `${ADSPOWER_API_URL}/status`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', {
        // "address":address , // mint接收底池
        // "rate":rate   // 建仓比例
        });
        console.log('AdsPower apiStatus GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower apiStatus Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 启动浏览器
 * @param param
 * @returns
 */
async function browserStart(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/browser/start`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', param // 请求参数
        );
        console.log('AdsPower browserStart GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower browserStart Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 关闭浏览器
 * @param param
 * @returns
 */
async function browserStop(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/browser/stop`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', param // 请求参数
        );
        console.log('AdsPower browserStop GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower browserStop Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 浏览器检查启动状态
 * @param param
 * @returns
 */
async function browserActive(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/browser/active`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', param // 请求参数
        );
        console.log('AdsPower browserActive GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower browserActive Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 创建分组
 * @param param
 * @returns
 */
async function groupCreate(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/group/create`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', param // 请求参数
        );
        console.log('AdsPower groupCreate POST:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower groupCreate Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 修改分组
 * @param param
 * @returns
 */
async function groupUpdate(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/group/update`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', param // 请求参数
        );
        console.log('AdsPower groupUpdate POST:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower groupUpdate Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 查询分组
 * @param param
 * @returns
 */
async function groupList(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/group/list`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', param // 请求参数
        );
        console.log('AdsPower groupList GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower groupList Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 应用分类列表
 * @param param
 * @returns
 */
async function applicationList(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/application/list`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', param // 请求参数
        );
        console.log('AdsPower applicationList GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower applicationList Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 新建浏览器
 * @param param
 * @returns
 */
async function userCreate(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/user/create`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', param // 请求参数
        );
        console.log('AdsPower applicationList GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower applicationList Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 更新环境信息
 * @param param
 * @returns
 */
async function userUpdate(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/user/update`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', param // 请求参数
        );
        console.log('AdsPower userUpdate GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower userUpdate Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 查询环境
 * @param param
 * @returns
 */
async function userlist(param) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/user/list`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', param // 请求参数
        );
        console.log('AdsPower userlist GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower userlist Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 删除环境
 * @param user_ids string[],  // 需要删除的环境ID，支持批量删除
 * @returns
 */
async function userDelete(user_ids) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/user/delete`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', { user_ids: user_ids } // 请求参数
        );
        console.log('AdsPower userDelete POST:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower userDelete Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 移动环境
 * @param user_ids 需要分组的环境ID，数组格式
 * @param group_id 对应的分组ID。
 * @returns
 */
async function userRegroup(user_ids, group_id) {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/user/regroup`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', { user_ids: user_ids } // 请求参数
        );
        console.log('AdsPower userRegroup POST:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower userRegroup Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 清除缓存
 * 注意事项：该接口会删除所有环境的本地缓存数据，请谨慎使用。如果想对指定的环境在打开后进行缓存删除，可使用启动浏览器接口中的"clear_cache_after_closing"。
 * @returns
 */
async function userDeleteCache() {
    try {
        let url = `${ADSPOWER_API_URL}/api/v1/user/delete-cache`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'POST', {} // 请求参数
        );
        console.log('AdsPower userDeleteCache POST:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('AdsPower userDeleteCache Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
//# sourceMappingURL=api.adspower.js.map