"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryFractalOrdPrice = queryFractalOrdPrice;
exports.insertFractalOrdAddress = insertFractalOrdAddress;
const api_common_1 = require("./api.common");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const FRACTAL_LAN_HOST = process.env.FRACTAL_LAN_HOST;
/**
 * 查询数据分析差价模型查询
 * @returns
 */
async function queryFractalOrdPrice(address, rate) {
    try {
        let url = `${FRACTAL_LAN_HOST}/v1/fb/query-fractal-ord-price`;
        console.log(`url:${url}`);
        const getResult = await (0, api_common_1.makeRequest)(url, 'GET', {
            "address": address, // mint接收底池
            "rate": rate // 建仓比例
        });
        console.log('queryFractalOrdPrice GET:', JSON.stringify(getResult));
        return getResult;
    }
    catch (error) {
        console.error('queryFractalOrdPrice Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 根据address写入FB铸造仓位信息
 * @param address mint地址
 * @param ticker 标的ticker名称
 * @param minted_total 本次新增mint数量
 */
async function insertFractalOrdAddress(address, ticker, minted_total) {
    try {
        const url = `${FRACTAL_LAN_HOST}/v1/fb/insert-fractal-ord-address`;
        console.log(`url:${url}`);
        // POST请求
        const postResult = await (0, api_common_1.makeRequest)(url, 'POST', {
            "address": address,
            "ticker": ticker,
            "minted_total": minted_total
        });
        return postResult;
    }
    catch (error) {
        console.error('POST Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
//# sourceMappingURL=fractal.lan.api.js.map