"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiStatus = apiStatus;
exports.browserStart = browserStart;
exports.browserStop = browserStop;
exports.browserActive = browserActive;
exports.groupCreate = groupCreate;
exports.groupUpdate = groupUpdate;
exports.groupList = groupList;
exports.userlist = userlist;
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const adspowerApiService = __importStar(require("./api/api.adspower"));
/**
 * API接口状态
 * @returns
 */
async function apiStatus() {
    try {
        const result = await adspowerApiService.apiStatus();
        return result;
    }
    catch (error) {
        console.error('apiStatus Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 启动浏览器
 * @param param
 * @returns
 */
async function browserStart(param) {
    try {
        const result = await adspowerApiService.browserStart(param);
        return result;
    }
    catch (error) {
        console.error('browserStart Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 关闭浏览器
 * @param param
 * @returns
 */
async function browserStop(param) {
    try {
        const result = await adspowerApiService.browserStop(param);
        return result;
    }
    catch (error) {
        console.error('browserStop Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 *
 * @param param
 * @returns
 */
async function browserActive(param) {
    try {
        const result = await adspowerApiService.browserActive(param);
        return result;
    }
    catch (error) {
        console.error('browserActive Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 创建分组
 * @param param
 * @returns
 */
async function groupCreate(param) {
    try {
        const result = await adspowerApiService.groupCreate(param);
        return result;
    }
    catch (error) {
        console.error('groupCreate Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 修改分组
 * @param param
 * @returns
 */
async function groupUpdate(param) {
    try {
        const result = await adspowerApiService.groupUpdate(param);
        return result;
    }
    catch (error) {
        console.error('groupUpdate Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 查询分组
 * @param param
 * @returns
 */
async function groupList(param) {
    try {
        param.page_size = 100;
        const result = await adspowerApiService.groupList(param);
        return result;
    }
    catch (error) {
        console.error('groupList Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
/**
 * 查询环境
 * @param param
 * @returns
 */
async function userlist(param) {
    try {
        param.page_size = 100;
        const result = await adspowerApiService.userlist(param);
        return result;
    }
    catch (error) {
        console.error('groupList Request Error:', error instanceof Error ? error.message : error);
        return null;
    }
}
//# sourceMappingURL=flow.adspower.task.js.map