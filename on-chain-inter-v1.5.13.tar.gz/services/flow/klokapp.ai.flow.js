"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.KlokappAutomation = void 0;
const path = __importStar(require("path"));
const os = require('os');
const uuid_1 = require("uuid"); // 导入 uuid 库
const puppeteer_extra_1 = __importDefault(require("puppeteer-extra"));
const puppeteer_extra_plugin_stealth_1 = __importDefault(require("puppeteer-extra-plugin-stealth"));
puppeteer_extra_1.default.use((0, puppeteer_extra_plugin_stealth_1.default)());
const proxyChain = __importStar(require("proxy-chain"));
const walletConfigs_1 = require("../../interface/walletConfigs"); // 接口定义
const okx_wallet_plugins_1 = require("../wallet.plugins/okx.wallet.plugins"); // 钱包插件
const fileUtils_1 = require("../../common/fileUtils");
const utils_1 = require("../../common/utils");
const decoratorsUtils_1 = require("../../common/decoratorsUtils");
// 主文件
const globalState_1 = require("../../globalState");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
// 浏览器配置
const CHROME_BROWSER_HEADLESS = (0, utils_1.strToBool)(process.env.CHROME_BROWSER_HEADLESS || "false"); // 默认有头模式
// mint钱包密码
const OKX_WALLET_PASSWORD = process.env.OKX_WALLET_PASSWORD;
/**
 * Klokapp 钱包自动化
 */
class KlokappAutomation {
    constructor(walletType) {
        this.browser = null;
        this.page = null;
        this.walletSetp = null;
        this.wallet = walletConfigs_1.walletConfigs[walletType];
    }
    /**
     * 获取钱包插件页面
     * 基于brower监听，这里有个大坑，循环监听会叠加targetcreated事件
     * @param randomDirName
     * @returns
     */
    async getWalletPage() {
        // 寻找插件
        return new Promise((resolve, reject) => {
            this.browser.on('targetcreated', async (target) => {
                const targetUrl = target.url();
                // 检查是否为 OKX Wallet 插件页面
                if (targetUrl.startsWith('chrome-extension://mcohilncbfahbmgdjkbpemcciiolgcge/notification.html')) {
                    let p = await target.page();
                    if (p) {
                        // 检查某些元素是否存在
                        console.log(`[chrome-extension]targetcreated 找到插件页面`);
                        resolve(p);
                        try {
                            console.log(`[chrome-extension] this.walletSetp:${this.walletSetp}`);
                            if (this.walletSetp == 1) {
                                await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 不能小于2.8s
                                await (0, okx_wallet_plugins_1.connectWalletOkxConfirm)(p);
                                console.log(`[chrome-extension] 钱包交互链接网站操作成功`);
                            }
                        }
                        catch (ex) {
                            console.log(`[chrome-extension] 操作出现异常，忽略处理`);
                        }
                    }
                    // console.log('[002]找到 OKX Wallet 页面，URL:', targetUrl);
                }
            });
        });
    }
    /**
     * APP模式启动一次，规避安全验证
     * @param randomDirName
     * @param proxyInfo
     */
    async initializeApp(randomDirName, proxyInfo) {
        const userDirPath = path.join(this.wallet.userDataDir, randomDirName);
        console.log(`[initializeApp] 用户数据目录设置：${userDirPath}`);
        var args = [
            '--flag-switches-begin',
            '--flag-switches-end',
            `--no-sandbox`, // 禁用沙箱限制
            `--disable-setuid-sandbox`,
            `--user-data-dir=${userDirPath}`, // 指定用户数据目录'--lang=en-US', // 设置浏览器语言为英语（美国）
            `--start-maximized`, // 模拟窗口最大化
            '--app=https://klokapp.ai'
        ];
        // 判断是否存在代理
        if (proxyInfo) {
            // 将代理转换为本地 HTTP 代理
            let proxyStr = `${proxyInfo.protocol}://${proxyInfo.username}:${proxyInfo.password}@${proxyInfo.host}:${proxyInfo.port}`;
            console.log(`打印proxyStr: ${proxyStr}`);
            const localProxy = await proxyChain.anonymizeProxy(proxyStr); // 代理
            console.log(`本地代理: ${localProxy} -> 原代理: ${proxyStr}`);
            // 添加代理
            args.push(`--proxy-server=${localProxy}`);
        }
        else {
            console.log(`未启动代理加载浏览器...`);
        }
        // 启动浏览器puppeteerExtra
        const browser = await puppeteer_extra_1.default.launch({
            headless: CHROME_BROWSER_HEADLESS, // 设置为 false 以便调试，生产环境可改为 true
            userDataDir: userDirPath,
            args: args,
            ignoreDefaultArgs: [
                '--enable-automation',
                '--disable-background-networking',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-breakpad',
                '--disable-client-side-phishing-detection',
                '--disable-component-extensions-with-background-pages',
                '--disable-default-apps',
                '--disable-dev-shm-usage',
                '--disable-extensions',
                '--disable-features=TranslateUI',
                '--disable-hang-monitor',
                '--disable-ipc-flooding-protection',
                '--disable-popup-blocking',
                '--disable-prompt-on-repost',
                '--disable-renderer-backgrounding',
                '--disable-sync',
            ]
        });
        // 等待10s
        await (0, utils_1.delay)(10000 + Math.ceil(Math.random() * 1000)); // 随机休眠
        // 等待10秒，直接关闭浏览器
        await browser.close();
    }
    /**
     * 初始化浏览器和插件
     * @param randomDirName 用户缓存根目录名
     * @param proxyInfo 代理信息
     */
    async initialize(randomDirName, proxyInfo) {
        const userDirPath = path.join(this.wallet.userDataDir, randomDirName);
        console.log(`用户数据目录设置：${userDirPath}`);
        // 插件版本目录
        const OKX_WALLET_EXTENSION_VERSION = process.env.OKX_WALLET_EXTENSION_VERSION || '3.45.22_0';
        // 浏览器args设置
        let args = [
            '--flag-switches-begin',
            '--flag-switches-end',
            `--user-data-dir=${userDirPath}`, // 指定用户数据目录
            `--disable-extensions-except=${path.join(this.wallet.extensionPath, OKX_WALLET_EXTENSION_VERSION)}`,
            `--load-extension=${path.join(this.wallet.extensionPath, OKX_WALLET_EXTENSION_VERSION)}`,
            `--no-sandbox`, // 禁用沙箱限制
            `--disable-setuid-sandbox`,
            '--lang=en-US', // 设置浏览器语言为英语（美国）
            `--start-maximized`, // 模拟窗口最大化
        ];
        // 判断是否存在代理
        if (proxyInfo) {
            // 将代理转换为本地 HTTP 代理
            let proxyStr = `${proxyInfo.protocol}://${proxyInfo.username}:${proxyInfo.password}@${proxyInfo.host}:${proxyInfo.port}`;
            console.log(`打印proxyStr: ${proxyStr}`);
            const localProxy = await proxyChain.anonymizeProxy(proxyStr); // 代理
            console.log(`本地代理: ${localProxy} -> 原代理: ${proxyStr}`);
            // 添加代理
            args.push(`--proxy-server=${localProxy}`);
        }
        else {
            console.log(`未启动代理加载浏览器...`);
        }
        // 启动浏览器
        this.browser = await puppeteer_extra_1.default.launch({
            headless: CHROME_BROWSER_HEADLESS, // 设置为 false 以便调试，生产环境可改为 true
            args: args,
            protocolTimeout: 90000
        });
        this.page = await this.browser.newPage(); // 创建一个新的页面
        // 设置用户代理为英语（美国）
        await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36');
        // 设置请求头中的 Accept-Language 为英语（美国）
        await this.page.setExtraHTTPHeaders({ 'Accept-Language': 'en-US,en;q=0.9', // 优先英语（美国），其次其他英语
        });
        // 设置视口的宽度和高度
        await this.page.setViewport({
            width: 1280, // 设置宽度
            height: 800, // 设置高度
            deviceScaleFactor: 1, // 设置设备像素比，默认为1
        });
    }
    /**
     * 导航到目标网站
     */
    async gotoWebsite(url) {
        if (!this.page || !this.browser)
            throw new Error('Browser or Page not initialized');
        // 然后导航到目标 URL
        await this.page.goto(url, { waitUntil: 'networkidle2' });
        // 关闭多余的页面
        await this.closeExtraPage();
        console.log('已导航到目标网页并关闭多余网页');
        // 延迟
        await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 500); // 随机休眠，2.5s-3s
        // // 验证代理 IP
        // const ip = await this.page.evaluate(() => {
        //     return fetch('https://api.ipify.org?format=json')
        //         .then(res => res.json())
        //         .then(data => data.ip);
        // });
        // console.log('当前 IP:', ip);
        return;
    }
    /**
     * 导入钱包（根据私钥导入）
     * @param privateKey 私钥
     */
    async importWallet(privateKey) {
        if (!this.page || !this.browser)
            throw new Error('Browser or Page not initialized');
        console.log('进入导入钱包流程，importWallet');
        // 等待钱包弹窗
        // const walletPage = await new Promise<Page>((resolve, reject) => {
        //   this.browser!.on('targetcreated', async (target: Target) => {
        //       const targetUrl = target.url();
        //       // 检查是否为 OKX Wallet 插件页面
        //       if (targetUrl.startsWith('chrome-extension://')) {
        //           let p = await target.page();
        //           if (p) {
        //               resolve(p);
        //           }
        //           console.log('找到Wallet 页面，URL:', targetUrl);
        //       }
        //   });
        // });
        const walletPage = await this.getWalletPage(); // 绑定钱包事件
        await walletPage.close();
        // console.log(`当前页面地址：${walletPage.url()}`);
        //chrome-extension://mcohilncbfahbmgdjkbpemcciiolgcge/notification.html
        // 关闭自动弹出得插件页面
        // 寻找多余得页面，进行关闭减少干扰
        const pages = await this.browser.pages();
        // 页面重新聚焦 
        const previousPage = pages[0]; // 根据url地址自动判断索引
        await previousPage.bringToFront(); // 聚焦到上一个页面
        console.log('已切换到上一个页面:', previousPage.url());
        // // 关闭多余的页面
        // await this.closeExtraPage();
        // 导入钱包私钥
        await (0, okx_wallet_plugins_1.importWalletOkx)(this.browser, privateKey, OKX_WALLET_PASSWORD);
        console.log('[Key Nodes] Start: Wallet connection completed!');
        await (0, utils_1.delay)(Math.ceil(Math.random() * 300) + 300); // 随机休眠，0.3-0.6s
    }
    /**
     * 关闭多余的页面
     */
    async closeExtraPage() {
        if (!this.page || !this.browser)
            throw new Error('Browser or Page not initialized');
        await this.page.bringToFront(); // 聚焦到目标页面
        const pages = await this.browser.pages();
        // 遍历所有页面，关闭插件页面
        for (const page of pages) {
            const url = page.url();
            if (page != this.page) {
                console.log(`关闭多余得页面:$${page.url()}`);
                await page.close(); // 非当前页，统统关闭
            }
        }
        console.log(`当前页面个数：${pages.length}`);
        await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
    }
    /**
     * 检测目录是否存在
     * @returns
     */
    async checkWalletStatus() {
        // 验证钱包导入状态
        const baseDir = `${path.join(path.resolve(__dirname, '../../../'), "data", "wallet", "okx", "Default", "Service Worker", "CacheStorage")}`;
        console.log(`验证钱包导入验证路径：${baseDir}`);
        // 首先需要检测目录是否存在
        const dirExist = await (0, fileUtils_1.checkDirExists)(baseDir);
        // 如果目录不存在，则肯定没有钱包导入；如果存在，需要判断该目录下是否存在文件
        if (dirExist) {
            // 目录信息
            const dirInfos = await (0, fileUtils_1.checkAllFolders)(baseDir);
            if (dirInfos.length > 0) {
                // 存在目录
                console.log(`目录检索：${JSON.stringify(dirInfos)}`);
                return true;
            }
            else {
                return false;
            }
        }
        return dirExist;
    }
    /**
     * 登录钱包
     * @param url 目标网址url
     */
    async loginWallet() {
        if (!this.page || !this.browser)
            throw new Error('Browser or Page not initialized');
        console.log('准备登录钱包');
        // await delay(Math.ceil(Math.random() * 2000) + 1000); // 随机休眠
        const walletPage1 = await this.getWalletPage(); // 绑定钱包事件
        await walletPage1.close();
        await this.page.bringToFront();
        // // 关闭多余的页面
        // await this.closeExtraPage();
        // await delay(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
        /**
         * 连接Wallet（1），解锁钱包，支持多种钱包类型
         * 多种钱包插件交互在wallet.plgins.ts中实现，后期可扩展到更多钱包类型（维护性更好）
         */
        const walletPage = await this.browser.newPage();
        await (0, okx_wallet_plugins_1.connectWalletOkx)(walletPage, OKX_WALLET_PASSWORD);
        // 输入密码之后，会弹出确认连接网站操作
        await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
        // 切换页面之后再关闭
        await this.page.bringToFront();
        // // 关闭多余的页面
        // await this.closeExtraPage();
        console.log('[Key Nodes] Restart: Wallet connection completed!');
    }
    /**
     * 连接钱包
     * @param url 目标网址url
     */
    async connectWallet() {
        if (!this.page || !this.browser)
            throw new Error('Browser or Page not initialized');
        console.log('准备连接钱包');
        try {
            // 操作页面元素，点击Connect Wallet按钮//button[text()=""]
            await this.page.waitForSelector(`::-p-xpath(//button[contains(text(), "Connect Wallet")])`, { visible: true });
            await this.page.click(`::-p-xpath(//button[contains(text(), "Connect Wallet")])`);
            await (0, utils_1.delay)(Math.ceil(Math.random() * 2000) + 1000); // 随机休眠
            console.log('开关点击连接钱包按钮');
            // 弹出层提示交互
            const okxHandle = await this.page.evaluateHandle(() => {
                const buttons = Array.from(document.querySelectorAll('button'));
                return buttons.find(button => button.textContent.includes('OKX Wallet'));
            });
            const okxButton = okxHandle.asElement();
            if (okxButton) {
                await okxButton.click();
                console.log('成功点击 OKX Wallet 按钮');
            }
            else {
                console.log('未找到 OKX Wallet 按钮');
            }
            await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
            console.log('准备操作连接钱包');
            // 会导致浏览器关闭不可见了
            const walletPage = await this.browser.newPage();
            // 再新得页面进行钱包连接操作
            await (0, okx_wallet_plugins_1.connectWalletOkxConfirm)(walletPage);
            // 第一次：连接操作
            await (0, utils_1.delay)(Math.ceil(Math.random() * 1800) + 400); // 不能小于2.8s
            // 切换到主页
            await this.page.bringToFront();
            // 等待足够的时间，确认连接的网络请求
            await (0, utils_1.delay)(Math.ceil(Math.random() * 6800) + 400); // 不能小于2.8s
            // 关闭多余的页面
            await this.closeExtraPage();
            console.log('[Connect Success] The operation was successfully submitted');
        }
        catch (ex) {
            console.trace(ex);
        }
    }
    /**
     * 登录网站
     */
    async signupWebSite(url) {
        if (!this.page || !this.browser)
            throw new Error('Browser or Page not initialized');
        console.log('[Signup WebSite] 准备Sign in');
        try {
            // 操作页面元素，点击Sign in按钮//button[text()=""]
            await this.page.waitForSelector(`::-p-xpath(//button[contains(text(), "Sign in")])`, { visible: true });
            await this.page.click(`::-p-xpath(//button[contains(text(), "Sign in")])`);
            await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
            console.log('[Signup WebSite] 操作了页面Sign in登录网站操作按钮');
            // 等待钱包弹窗，全局监控，这里等待即可
            this.getWalletPage(); // 绑定钱包事件
            console.log('[Signup WebSite] 找到钱包插件');
            // 等待钱包弹窗
            // const walletPage = await new Promise<Page>((resolve, reject) => {
            //   this.browser!.on('targetcreated', async (target: Target) => {
            //       const targetUrl = target.url();s
            //       // 检查是否为 OKX Wallet 插件页面
            //       if (targetUrl.startsWith('chrome-extension://')) {
            //           let p = await target.page();
            //           if (p) {
            //               resolve(p);
            //           }
            //           console.log('找到Wallet 页面，URL:', targetUrl);
            //       }
            //   });
            // });
            // console.log('[Signup WebSite] 通过钱包登录网站，已经完成');
            await (0, utils_1.delay)(Math.ceil(Math.random() * 9000) + 1000); // 随机休眠
            // // 页面重定向
            // await this.page.goto(url);
            // await delay(Math.ceil(Math.random() * 2000) + 1000); // 随机休眠
            // const walletPage = await this.browser.newPage();
            // await connectWalletOkxConfirm(walletPage);
            // await delay(Math.ceil(Math.random() * 2000) + 1000); // 随机休眠
            // 关闭多余的页面
            // await this.closeExtraPage();
            // await delay(Math.ceil(Math.random() * 3800) + 1000); // 随机休眠
            console.log('[Connect Success] The operation was successfully loginWebSite');
        }
        catch (ex) {
            console.trace(ex);
            // 出现异常，重新初始化
        }
    }
    /**
     * 执行 Mint 页面数据填充操作
     * @param url 交互地址
     * @param questions 需要交互得问题清单
     */
    async performSwap(url, questions) {
        if (!this.page || !this.browser)
            throw new Error('Page not initialized');
        // 判断页面是否已经重定向
        if (!this.page.url().includes(url)) {
            // 重定向到新的网页
            await this.page.goto(url, { waitUntil: 'networkidle2' });
        }
        await (0, utils_1.delay)(Math.ceil(Math.random() * 5000) + 1000); // 随机休眠，2.6s-3.2s
        // 检测是否弹出了提示框
        console.log('[Perform Swap] Start performSwap...');
        // 点击复制邀请连接
        await this.page.waitForSelector(`::-p-xpath(//button[contains(text(), "Copy Referral Link")])`, { visible: true });
        await this.page.click(`::-p-xpath(//button[contains(text(), "Copy Referral Link")])`);
        console.log('[Perform Swap] 已经点击复制分享URL，开始执行从剪贴板获取内容');
        // 在页面中创建一个隐藏的 input 元素，并设置唯一 id
        await this.page.evaluate(() => {
            const input = document.createElement('input');
            input.setAttribute('id', 'puppeteer-clipboard-input'); // 设置唯一 id
            input.style.position = 'absolute'; // 隐藏元素
            input.style.left = '-9999px'; // 移出可视区域
            document.body.appendChild(input);
            input.focus(); // 确保焦点在 input 上
        });
        // 模拟粘贴操作（Ctrl+V 或 Cmd+V）
        const platform = os.platform();
        console.log(`[Perform Swap] 当前系统平台：${platform}`);
        if (platform == 'darwin') {
            // 模拟粘贴操作（macOS 使用 Meta）
            await this.page.keyboard.down('Meta'); // macOS
            await this.page.keyboard.press('V');
            await this.page.keyboard.up('Meta');
        }
        else {
            await this.page.keyboard.down('Control'); // Windows/Linux
            await this.page.keyboard.press('V');
            await this.page.keyboard.up('Control'); // Windows/Linux
        }
        // 读取 input 的值
        const link = await this.page.evaluate(() => {
            const input = document.querySelector('#puppeteer-clipboard-input');
            return input?.value;
        });
        console.log(`[Perform Swap] 从剪贴板中粘贴内容：${link}`);
        if (link) {
            // 当获取内容时候
            const referral_code = (0, utils_1.getUrlParameter)(link, "referral_code");
            if (referral_code) {
                // 需要先检测全局变量，邀请码列表中是否存在本轮邀请码（去重写入）
                const code = globalState_1.globalReferralCode.KLOKAPP_REFERRAL_CODE.find(c => c === referral_code);
                console.log(`[Perform Swap] 检索全局变量中是否存在本次任务得邀请码:${code}`);
                if (!code) {
                    // 如果没找到，该账号是第一次出现，记录到全局变量中，并写入文件中
                    globalState_1.globalReferralCode.KLOKAPP_REFERRAL_CODE.push(referral_code);
                    // 追加写入文件
                    await (0, fileUtils_1.appendResultToFile)(path.join(__dirname, '../../', 'data', 'task', `klokapp_code.txt`), referral_code);
                    console.log(`[Perform Swap] 检测到该邀请码首次出现，加入邀请码文件中:${referral_code}`);
                }
            }
        }
        // 抽取问题循环
        for (var i in questions) {
            console.log(`[Perform Swap] 问题输出:${questions[i]}`);
            await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠，2.6s-3.2s
            // 点击添加问题
            await this.page.waitForSelector(`a[href="/app"]`, { visible: true });
            await this.page.click(`a[href="/app"]`);
            await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠，2.6s-3.2s
            // 问题输入框选择器
            const inputSelector = 'textarea[name="message"]';
            // // 等待输入框可用
            // await this.waitForInputEnabled(this.page,inputSelector,12000);
            // console.log(`inputSelector:${inputSelector}, 问题输入框已经可用`);
            // 清空输入框
            await this.page.waitForSelector(inputSelector);
            await this.page.focus(inputSelector); // 聚焦输入框
            // 清除输入框中的值
            await this.page.click(inputSelector, { clickCount: 3 }); // 三次点击以选中所有文本
            await this.page.keyboard.press('Backspace'); // 删除选中的文本
            await (0, utils_1.delay)(Math.ceil(Math.random() * 200) + 200); // 随机休眠，2.6s-3.2s
            // 填充问题
            await this.page.waitForSelector(inputSelector, { visible: true });
            await this.page.type(inputSelector, questions[i]);
            await (0, utils_1.delay)(Math.ceil(Math.random() * 2000) + 1000); // 随机休眠，2.6s-3.2s
            // 提交问题
            await this.page.waitForSelector(`button[type="submit"]`, { visible: true });
            await this.page.click(`button[type="submit"]`);
            console.log(`[Perform Swap] button[type="submit"] 已经提交操作`);
            // 问题答案打印时间普遍在20s，页面停留
            await (0, utils_1.delay)(Math.ceil(Math.random() * 25000) + 5000); // 随机休眠
            console.log(`[Perform Swap] 问题:${i}, 执行完成。`);
        }
        console.log(`[Perform Swap] Swap transaction request submission completed`);
        return;
    }
    /**
     * 等待input输入可以输入
     * @param page
     * @param selector
     * @param timeout
     */
    async waitForInputEnabled(page, selector, timeout = 30000) {
        try {
            await page.waitForFunction((sel) => {
                const input = document.querySelector(sel);
                return input && !input.disabled;
            }, { timeout }, selector);
        }
        catch (ex) {
            console.log(`waitForInputEnabled() 出现异常`);
            // console.trace(ex);
        }
    }
    // 关闭浏览器
    async close() {
        if (this.browser) {
            await this.browser.close();
            console.log('浏览器已关闭');
        }
    }
    /**
     * 执行任务流程
     * @param privateKey 钱包私钥
     * @param proxyStr 代理
     * @param qs 问题列表
     * @param inviteCode 邀请码
     * @returns
     */
    async run(privateKey, proxyStr, qs, inviteCode) {
        try {
            console.log(`即将执行任务，邀请码:${inviteCode}`);
            // 从本地缓存中获取钱包导入状态
            let WALLET_IMPORT_STATE_KEY = globalState_1.globalState.WALLET_IMPORT_STATE_KEY;
            // 再检查配置文件是否存在
            const OKX_USER_DATA_DIR = process.env.OKX_USER_DATA_DIR || "";
            if (WALLET_IMPORT_STATE_KEY == "" && OKX_USER_DATA_DIR != "") {
                // 取配置文件中的用户缓存目录名称
                WALLET_IMPORT_STATE_KEY = OKX_USER_DATA_DIR;
            }
            console.log(`钱包导入状态结果：${WALLET_IMPORT_STATE_KEY}`);
            // 判断钱包是否需要执行导入动作
            let action = true; // true-需要导入，false-不需要导入
            // 分两种情况：一种是存在值（需要二次检测文件目录是否存在），一种是不存在值（不存在值肯定需要导入）
            if (WALLET_IMPORT_STATE_KEY !== "") {
                // 看上去钱包已经导入了，根据名称检测目录是否存在
                const randomDirPath = path.join(this.wallet.userDataDir, WALLET_IMPORT_STATE_KEY);
                // 检测目录是否存在
                const dirExist = await (0, fileUtils_1.checkDirExists)(randomDirPath);
                if (dirExist) {
                    // 存在目录
                    action = false; //不需要导入
                }
                else {
                    // 目录不存在，依然需要重新导入钱包
                    action = true; // 需要导入
                }
            }
            // 对目标网站进行交互
            var targetUrl = `https://klokapp.ai?referral_code=${inviteCode}`;
            // 代理信息
            console.log(`代理信息：${proxyStr}`);
            var proxyInfo = null;
            ;
            if (proxyStr != '') {
                proxyInfo = (0, utils_1.parseProxyUrl)(proxyStr);
            }
            console.log(`格式化得代理信息：${proxyInfo}`);
            // 判断是否需要导入钱包操作
            if (action) {
                // 创建一个随机目录，用于存放钱包缓存
                const randomDirName = (0, uuid_1.v4)(); // 生成一个 UUID 作为目录名
                // 基础目录，如果没有，则递归创建
                await (0, fileUtils_1.createDirectory)(this.wallet.userDataDir);
                // 删除缓存目录
                await (0, fileUtils_1.deleteDirectoryContents)(this.wallet.userDataDir);
                await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
                // 突破限制
                await this.initializeApp(randomDirName, proxyInfo);
                // 进入目标页面：先完成钱包账户关联（一次性操作）
                await this.initialize(randomDirName, proxyInfo); // 初始化浏览器和插件
                // 执行导入钱包得操作，不需要二次输入密码交互
                // 首次进入执行钱包导入
                await this.importWallet(privateKey); // 导入钱包（针对已经导入的钱包直接执行操作）
                // 导入成功，需要将导入状态存储到内存
                globalState_1.globalState.WALLET_IMPORT_STATE_KEY = randomDirName; // 将导入状态存储到内存
            }
            else {
                // 进入目标页面：先完成钱包账户关联（一次性操作）
                await this.initialize(WALLET_IMPORT_STATE_KEY, proxyInfo); // 初始化浏览器和插件
                /**
                 * 连接Wallet（1），解锁钱包，支持多种钱包类型
                 * 多种钱包插件交互在wallet.plgins.ts中实现，后期可扩展到更多钱包类型（维护性更好）
                 */
                await this.loginWallet(); // 针对已经导入得钱包，重新打开浏览器需要密码登录
            }
            await this.page?.bringToFront(); // 聚焦到当前页面
            // 打开目标网站并关闭多余得页面
            await this.gotoWebsite(targetUrl);
            await (0, utils_1.delay)(9000); // 随机休眠
            // 临时变量，使用本地缓存
            var _url = "";
            const url = "https://klokapp.ai/app"; // 进行页面交互
            // 如果当前页面已经发生跳转，则表示页面已经重启过
            _url = await this.page?.url() ?? "";
            // 比对结果，如果发生跳转执行下一步
            if (!_url?.startsWith('https://klokapp.ai/app')) {
                // 这里需要网站是否已经完成连接钱包（但是未登录网站）
                try {
                    var disconnectSelector = '::-p-xpath(//button[contains(text(), "Disconnect")])';
                    const elementHandle = await this.page.$(disconnectSelector);
                    if (!elementHandle) {
                        // 不可见，表示还没连接过钱包，执行连接钱包
                        console.log(`[Wallet Connetc] Disconnect 不可见，网站还没连接过钱包，执行钱包连接`);
                        // 钱包已经导入，从网页连接钱包
                        await this.connectWallet(); //
                    }
                }
                catch (ex) {
                    // 不可见，表示还没连接过钱包，执行连接钱包
                    console.log(`[Wallet Connetc] Disconnect 识别异常，有可能已经跳转到到交互页面`);
                    // 钱包已经导入，从网页连接钱包
                }
                this.walletSetp = 1; //操作步骤
                await (0, utils_1.delay)(3000); // 随机休眠
                console.log(`已经开始登录`);
                // 判断页面是否已经重定向
                var retryLogin = 0;
                // 登录网站，如果登录失败，重试10次
                try {
                    // 进行登录
                    await this.signupWebSite(url);
                }
                catch (ex) {
                    console.log(`[Sign Up] 操作登录网站交互出现异常`);
                }
                while (retryLogin < 12) {
                    console.log(`正在执行登录等待:{${retryLogin}}`);
                    await (0, utils_1.delay)(5000); // 固定休眠5s
                    // 获取页面是否已经完成跳转
                    _url = await this.page?.url() ?? "";
                    // 比对结果，如果发生跳转执行下一步
                    if (_url?.startsWith('https://klokapp.ai/app')) {
                        retryLogin = 100; // 100 表示登录成功
                    }
                    else {
                        retryLogin++; // 递增重试次数
                    }
                }
                // 登录执行完成，如果没有登录成功，则退出本次任务
                if (retryLogin !== 99) {
                    return 'fail'; // 任务失败，不执行本次任务
                }
                console.log(`执行登录成功，进入目标交互页面`);
            }
            // 进行页面交互，进行swap操作
            await this.performSwap(url, qs); // 打开铭文铸造页面
            // 等一分钟，暂停等待演示效果
            await (0, utils_1.delay)(Math.ceil(Math.random() * 1000) + 1000); // 随机休眠
            console.log(`任务完成，可以关闭浏览器了。`);
            return "ok";
            // 程序执行到这里，需要关闭浏览器，不然无法继续mint
        }
        catch (error) {
            console.error('发生错误:', error);
            return "fail";
        }
        finally {
            console.log(`finally:正在执行关闭浏览器`);
            await this.close();
        }
    }
}
exports.KlokappAutomation = KlokappAutomation;
__decorate([
    (0, decoratorsUtils_1.timeout)(600000)
], KlokappAutomation.prototype, "performSwap", null);
//# sourceMappingURL=klokapp.ai.flow.js.map