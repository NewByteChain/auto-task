"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDexData = getDexData;
const monad_page_data_1 = require("./flow/monad.page.data"); // Monad工作流
const swap_octo_trade_1 = require("./flow/swap.octo.trade");
const magiceden_monad_1 = require("./flow/magiceden.monad"); // OKX数据
const cex_binance_trade_1 = require("./flow/cex.binance.trade"); // OKX数据
const wallet_bat_1 = require("./wallet/wallet.bat");
const walletBatSomnia = __importStar(require("./wallet/wallet.bat.somnia"));
// AdsPower工作流
const adspower_incentiv_flow_1 = require("./flow/adspower.incentiv.flow"); // AdsPower工作流
// import { timeout }  from '../common/decoratorsUtils';
const crypto = __importStar(require("crypto"));
/**
 * 测试Monad自动化
 * @returns
 */
const monad = async () => {
    const automation = new monad_page_data_1.MonadAutomation('okx'); // 可切换为 okx、metamask 或 phantom
    const swapParams = {
        fromToken: 'MON',
        toToken: 'DAK',
        amount: '0.1',
    };
    await automation.run();
};
/**
 * 查询somnia余额
 */
const somnia = async () => {
    await walletBatSomnia.balancesQuery();
};
/**
 * octo工作流
 * @returns
 */
const octo = async () => {
    const client = new swap_octo_trade_1.OctoAutomation('okx');
    // 执行
    client.run();
};
// magicEden
const me = async () => {
    const magicEden = new magiceden_monad_1.MagicEdenAutomation('metamask'); // 可切换为 okx、metamask 或 phantom
    await magicEden.run();
};
/**
 * 测试钱包批量操作
 */
const walletHelper = async () => {
    const walletHelper = new wallet_bat_1.WalletHelper(); // 可切换为 okx、metamask 或 phantom
    // await walletHelper.run()
    await walletHelper.runNewWallet(1000, 128); // 创建钱包
};
/**
 * 获取币安交易所数据
 * @returns
 */
const getBinanceTradeData = async () => {
    var targetUrl = 'https://www.binance.com/zh-CN/trade/BTC_USDT?type=spot';
    // 需要抓取多个ajax api数据接口
    var ajaxUrl = [
        `https://www.binance.com/api/v1/aggTrades`, // 交易数据
        `https://www.binance.com/api/v3/uiKlines` // K线图数据
    ];
    const binanceAutomation = new cex_binance_trade_1.BinanceAutomation();
    const data = await binanceAutomation.getBinanceTradeData(targetUrl, ajaxUrl);
    // 返回结果
    var result = {};
    // 获取数据，根据键值对获取结果数据（实际网页输出api接口顺序不固定）
    result['trades'] = data[crypto.createHash('md5').update(ajaxUrl[0]).digest('hex')];
    result['uiKlines'] = data[crypto.createHash('md5').update(ajaxUrl[1]).digest('hex')];
    return result;
};
// Incentiv任务
const flowIncentivAutomation = async () => {
    const incentivAutomation = new adspower_incentiv_flow_1.IncentivAutomation();
    // ads浏览器参数
    const adsInfo = {};
    // 代理信息
    const proxyStr = '';
    // 执行
    await incentivAutomation.run(adsInfo, proxyStr);
};
// 使用示例
async function getDexData(body) {
    /**
     * 钱包
     */
    // monad 领水查询
    // await monadBalancesQuery();
    // // ETH钱包
    const walletHelper = new wallet_bat_1.WalletHelper(); // 可切换为 okx、metamask 或 phantom
    // 导出钱包工具
    await walletHelper.readerRun();
    // 创建钱包（助记词）
    // await walletHelper.runNewWallet(10000,128);  // 创建钱包
    // somnia(); // somnia钱包查询
    // BTC钱包查询
    // btcWalletQuery();
    /**
     * 自动化工作流程
     */
    // // OCTO auto mint
    // await octo();
    // klokapp auto mint
    // await klokapp();
    // 币安测试
    // const data = await getBinanceTradeData();
    // return data;
    //Magiceden auto mint
    // me();
    // await walletTools.readerProxiesArrayOutTxt();
    // // 查询ETH余额
    // await queryBatchEthBalances();
    // // 读取公钥地址列表
    // await queryBatchEthPublickAddress();
    await flowIncentivAutomation(); // AdsPower工作流
    return 'ok';
}
//# sourceMappingURL=mutual.service.js.map