"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.taskOctoAutoSwap = taskOctoAutoSwap;
exports.taskKlokappAutoFlow = taskKlokappAutoFlow;
exports.taskCoreskyAutoFlow = taskCoreskyAutoFlow;
exports.taskSomniaAutoFlow = taskSomniaAutoFlow;
exports.taskMahojinAutoFlow = taskMahojinAutoFlow;
exports.taskSatsterminalAutoFlow = taskSatsterminalAutoFlow;
// 导入模块
const swap_octo_trade_1 = require("../flow/swap.octo.trade");
const flow_klokapp_task_1 = require("../flow.klokapp.task");
const flow_coresky_task_1 = require("../flow.coresky.task");
const flow_somnia_task_1 = require("../flow.somnia.task");
const flow_mahojin_task_1 = require("../flow.mahojin.task");
const flow_satsterminal_task_1 = require("../flow.satsterminal.task");
/**
 * 任务状态标志
 */
let TASK_STATUS_OCTO_AUTO_MINT = false;
let TASK_STATUS_KLOKAPP_AUTO_MINT = false;
let TASK_STATUS_CORESKY_AUTO_MINT = false;
let TASK_STATUS_SOMNIA_AUTO_MINT = false;
let TASK_STATUS_MAHOJIN_AUTO_MINT = false;
let TASK_STATUS_SATSTERMINAL_AUTO_MINT = false;
/**
 * Octo Auto Swap
 */
async function taskOctoAutoSwap() {
    // console.log(`进入taskOctoAutoMint()...`)
    const client = new swap_octo_trade_1.OctoAutomation('okx'); // 可切换为 okx、metamask 或 phantom
    // 判断任务是否正在执行过程中
    if (TASK_STATUS_OCTO_AUTO_MINT) {
        // 正在执行
        // console.warn(`[taskOctoAutoMint]已有任务正在执行,当前任务自动退出!!!`);
        return;
    }
    TASK_STATUS_OCTO_AUTO_MINT = true;
    try {
        // 执行拉取数据任务
        await client.run();
        // 解锁
        TASK_STATUS_OCTO_AUTO_MINT = false;
    }
    catch (ex) {
        // console.error(`[taskOctoAutoMint]任务执行遭遇错误,当前任务自动退出`);
        TASK_STATUS_OCTO_AUTO_MINT = false;
        throw ex;
    }
}
/**
 * Klokapp Auto Mint
 */
async function taskKlokappAutoFlow() {
    // console.log(`进入[taskKlokappAutoMint()]...`)
    // const client = new KlokappAutomation('okx'); // 可切换为 okx、metamask 或 phantom
    // 判断任务是否正在执行过程中
    if (TASK_STATUS_KLOKAPP_AUTO_MINT) {
        // 正在执行
        // console.warn(`[taskKlokappAutoMint]已有任务正在执行,当前任务自动退出!!!`);
        return;
    }
    TASK_STATUS_KLOKAPP_AUTO_MINT = true;
    try {
        // 执行拉取数据任务
        await (0, flow_klokapp_task_1.runKlokappAutoFlow)();
        // 解锁
        TASK_STATUS_KLOKAPP_AUTO_MINT = false;
    }
    catch (ex) {
        // console.error(`[taskKlokappAutoMint]任务执行遭遇错误,当前任务自动退出`);
        TASK_STATUS_KLOKAPP_AUTO_MINT = false;
        throw ex;
    }
}
/**
 * Coresky Auto Flow
 * @returns
 */
async function taskCoreskyAutoFlow() {
    // console.log(`进入[taskKlokappAutoMint()]...`)
    // const client = new KlokappAutomation('okx'); // 可切换为 okx、metamask 或 phantom
    // 判断任务是否正在执行过程中
    if (TASK_STATUS_CORESKY_AUTO_MINT) {
        // 正在执行
        // console.warn(`[taskKlokappAutoMint]已有任务正在执行,当前任务自动退出!!!`);
        return;
    }
    TASK_STATUS_CORESKY_AUTO_MINT = true;
    try {
        // 执行拉取数据任务
        await (0, flow_coresky_task_1.runCoreskyAutoFlow)();
        // 解锁
        TASK_STATUS_CORESKY_AUTO_MINT = false;
    }
    catch (ex) {
        // console.error(`[taskKlokappAutoMint]任务执行遭遇错误,当前任务自动退出`);
        TASK_STATUS_CORESKY_AUTO_MINT = false;
        throw ex;
    }
}
/**
 * Somnia Auto Flow
 * @returns
 */
async function taskSomniaAutoFlow() {
    // 判断任务是否正在执行过程中
    if (TASK_STATUS_SOMNIA_AUTO_MINT) {
        return;
    }
    TASK_STATUS_SOMNIA_AUTO_MINT = true;
    try {
        // 执行拉取数据任务
        await (0, flow_somnia_task_1.runSomniaAutoFlow)();
        // 解锁
        TASK_STATUS_SOMNIA_AUTO_MINT = false;
    }
    catch (ex) {
        // console.error(`[taskKlokappAutoMint]任务执行遭遇错误,当前任务自动退出`);
        TASK_STATUS_SOMNIA_AUTO_MINT = false;
        throw ex;
    }
}
/**
 * Mahojin Auto Flow
 * @returns
 */
async function taskMahojinAutoFlow() {
    // 判断任务是否正在执行过程中
    if (TASK_STATUS_MAHOJIN_AUTO_MINT) {
        return;
    }
    TASK_STATUS_MAHOJIN_AUTO_MINT = true;
    try {
        // 执行拉取数据任务
        await (0, flow_mahojin_task_1.runMahojinAutoFlow)();
        // 解锁
        TASK_STATUS_MAHOJIN_AUTO_MINT = false;
    }
    catch (ex) {
        // console.error(`[taskMahojinAutoFlow]任务执行遭遇错误,当前任务自动退出`);
        TASK_STATUS_MAHOJIN_AUTO_MINT = false;
        throw ex;
    }
}
/**
 * Satsterminal Auto Flow
 * @returns
 */
async function taskSatsterminalAutoFlow() {
    // 判断任务是否正在执行过程中
    if (TASK_STATUS_SATSTERMINAL_AUTO_MINT) {
        return;
    }
    TASK_STATUS_SATSTERMINAL_AUTO_MINT = true;
    try {
        // 执行拉取数据任务
        await (0, flow_satsterminal_task_1.runSatsterminalAutoFlow)();
        // 解锁
        TASK_STATUS_SATSTERMINAL_AUTO_MINT = false;
    }
    catch (ex) {
        TASK_STATUS_SATSTERMINAL_AUTO_MINT = false;
        throw ex;
    }
}
//# sourceMappingURL=task.auto.mutual.js.map